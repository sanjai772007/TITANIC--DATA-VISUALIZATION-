import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("train.csv")

fig, axes = plt.subplots(2, 3, figsize=(16,10))
fig.subplots_adjust(hspace=0.5, wspace=0.35)

sns.countplot(x='Survived', data=df, ax=axes[0,0])
axes[0,0].set_title("Survival Count")

gender=df[df['Survived']==1]['Sex'].value_counts()
axes[0,1].pie(gender,labels=gender.index,autopct='%1.1f%%',startangle=90)
axes[0,1].set_title("Survived by Gender")

pd.crosstab(df['Pclass'],df['Survived']).plot(kind='bar',stacked=True,ax=axes[0,2])
axes[0,2].set_title("Survival by Passenger Class")

sns.histplot(df['Age'].dropna(),bins=20,kde=True,ax=axes[1,0])
axes[1,0].set_title("Age Distribution")

sns.scatterplot(data=df,x='Fare',y='Age',hue='Survived',ax=axes[1,1])
axes[1,1].set_title("Fare vs Age")

axes[1,2].axis('off')
plt.show()
