# Titanic Data Visualization

A Python project analysing the Titanic dataset using Pandas, Matplotlib and Seaborn.

## Files
- titanic.py
- train.csv
- requirements.txt
- screenshots/

Run:
```bash
python3 titanic.py
```
